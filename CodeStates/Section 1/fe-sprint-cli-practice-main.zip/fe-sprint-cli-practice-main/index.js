const getListMultiplesOfTwo = require('./getListMultiplesOfTwo');

console.log('100 이하 2의 배수는 다음과 같습니다.');
console.log(getListMultiplesOfTwo(100));